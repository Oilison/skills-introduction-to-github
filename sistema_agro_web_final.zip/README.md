
# Sistema Agropecuário Web

Este sistema foi desenvolvido com Streamlit para controle de clientes e contas a receber, focado no setor agropecuário.

## Recursos

- Cadastro de clientes
- Registro de contas a receber
- Exportação de relatórios
- Análises com IA (OpenAI)
- Interface amigável via navegador

## Como rodar

1. Instale as dependências:
```
pip install -r requirements.txt
```

2. Rode a aplicação:
```
streamlit run app.py
```

## API Key

Adicione sua chave OpenAI como variável de ambiente ou diretamente no código:
```
OPENAI_API_KEY = "sua-chave"
```


# (versão adaptada para web com Streamlit)
import streamlit as st
import sqlite3
import pandas as pd
from datetime import datetime
import openai
import os

# Configurações iniciais
oepnai_key = os.getenv("OPENAI_API_KEY")
openai.api_key = oepnai_key if oepnai_key else "SUA_CHAVE_OPENAI"

conn = sqlite3.connect("sistema_agro.db", check_same_thread=False)
cursor = conn.cursor()

# Criação das tabelas
cursor.execute('''CREATE TABLE IF NOT EXISTS clientes (nome TEXT, contato TEXT, endereco TEXT)''')
cursor.execute('''CREATE TABLE IF NOT EXISTS contas_receber (cliente TEXT, valor REAL, vencimento TEXT)''')
conn.commit()

# Funções auxiliares
def salvar_cliente(nome, contato, endereco):
    cursor.execute("INSERT INTO clientes VALUES (?, ?, ?)", (nome, contato, endereco))
    conn.commit()

def listar_clientes():
    return pd.read_sql("SELECT rowid, * FROM clientes", conn)

def salvar_conta(cliente, valor, vencimento):
    cursor.execute("INSERT INTO contas_receber VALUES (?, ?, ?)", (cliente, valor, vencimento))
    conn.commit()

def listar_contas():
    return pd.read_sql("SELECT rowid, * FROM contas_receber", conn)

def gerar_analise_ia(texto):
    try:
        resposta = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": texto}]
        )
        return resposta.choices[0].message.content
    except Exception as e:
        return f"Erro: {e}"

# Interface Streamlit
st.set_page_config(page_title="Sistema Agropecuário", layout="wide")
st.title("Sistema de Gestão Agropecuária")

menu = st.sidebar.selectbox("Menu", ["Clientes", "Contas a Receber", "Relatórios", "IA", "Sobre"])

if menu == "Clientes":
    st.subheader("Cadastro de Clientes")
    with st.form(key="form_cliente"):
        nome = st.text_input("Nome")
        contato = st.text_input("Contato")
        endereco = st.text_input("Endereço")
        if st.form_submit_button("Salvar Cliente"):
            salvar_cliente(nome, contato, endereco)
            st.success("Cliente cadastrado com sucesso!")

    st.subheader("Clientes Cadastrados")
    st.dataframe(listar_clientes())

elif menu == "Contas a Receber":
    st.subheader("Registrar Contas a Receber")
    with st.form(key="form_conta"):
        cliente = st.text_input("Cliente")
        valor = st.number_input("Valor", min_value=0.0, step=0.01)
        vencimento = st.date_input("Vencimento")
        if st.form_submit_button("Registrar"):
            salvar_conta(cliente, valor, vencimento.strftime('%Y-%m-%d'))
            st.success("Conta registrada com sucesso!")

    st.subheader("Contas Registradas")
    st.dataframe(listar_contas())

elif menu == "Relatórios":
    st.subheader("Relatórios")
    st.write("Exportar e visualizar relatórios (em desenvolvimento)")
    if st.button("Exportar Clientes para Excel"):
        df = listar_clientes()
        df.to_excel("clientes.xlsx", index=False)
        st.success("Arquivo gerado: clientes.xlsx")

elif menu == "IA":
    st.subheader("Análise Inteligente")
    prompt = st.text_area("Descreva a situação ou dúvida:", "Gerar um resumo financeiro mensal...")
    if st.button("Analisar com IA"):
        resposta = gerar_analise_ia(prompt)
        st.write(resposta)

elif menu == "Sobre":
    st.markdown("""
        ### Sobre o Sistema
        Este sistema foi desenvolvido para gerenciamento de vendas, estoque e clientes do setor agropecuário.

        - Cadastro de clientes e contas
        - Relatórios em Excel
        - Análises com IA
        - Banco de dados local (SQLite)
        """)
